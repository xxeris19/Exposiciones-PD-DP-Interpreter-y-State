package state;
interface EstadoMario {
    void obtenerHongo();
    void obtenerFlor();
    void chocarEnemigo();
}