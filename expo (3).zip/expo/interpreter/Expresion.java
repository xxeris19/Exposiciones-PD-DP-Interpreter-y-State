package interpreter;

public interface Expresion {
    String interpretar(); 
}
