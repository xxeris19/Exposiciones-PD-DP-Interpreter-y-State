package interpreter;


public class Saludar implements Expresion{

    private Expresion regularExpresion1;
    private Expresion regularExpresion2;
    private Expresion terminalExpresion; 
    
    public Saludar(Expresion regExpresion1, Expresion regExpresion2, Expresion terminalExpresion) {
        this.regularExpresion1 = regExpresion1;
        this.terminalExpresion = terminalExpresion; 
        this.regularExpresion2 = regExpresion2;
    }
    
    @Override
    public String interpretar() {
        boolean cadenaNoValida = false;
        
        String[] palabras = {
            regularExpresion1.interpretar(),
            regularExpresion2.interpretar(),
            terminalExpresion.interpretar()
        };

        for (String palabra : palabras) {
            if(! (Diccionario.DICCIONARIO.containsKey(palabra) && Diccionario.DICCIONARIO.get(palabra))) {
                cadenaNoValida = true; 
                break; 
            }
        }

        if(cadenaNoValida == false) {
            return regularExpresion1.interpretar() +" " + terminalExpresion.interpretar() +" " + regularExpresion2.interpretar();
        }else {
            return "cadena no valida";
        }
    }
    
}
