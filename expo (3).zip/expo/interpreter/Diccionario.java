package interpreter;

import java.util.HashMap;
import java.util.Map;

public class Diccionario {
    public static final  Map<String, Boolean> DICCIONARIO = new HashMap<String,Boolean>() {
        {put("Hola", true);
        put("Mundo", true);
        put(".", true);
        put(",", false);}
    };
}
