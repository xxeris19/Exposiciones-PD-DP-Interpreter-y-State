package state;
public class Main {
    public static void main(String[] args) {
        Mario mario = new Mario();

        mario.chocarEnemigo(); //

        mario.obtenerHongo(); 
        mario.obtenerFlor(); 

        mario.chocarEnemigo(); 
        mario.obtenerHongo(); 
    }
} 
